# serverwofacade
This is the program accompany the Component-Based Software Developemnt Course by Sarun Intakosum. 
The student needs to fork this repo and modify the program by applying Facade design pattern.
